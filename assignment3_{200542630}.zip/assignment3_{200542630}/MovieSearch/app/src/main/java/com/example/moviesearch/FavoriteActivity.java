package com.example.moviesearch;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.*;

public class FavoriteActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FavoriteMovieAdapter adapter;
    private List<Favorite> favoriteList = new ArrayList<>();
    private FirebaseFirestore db;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        recyclerView = findViewById(R.id.recyclerViewFavorites);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        loadFavorites();
    }

    private void loadFavorites() {
        DocumentReference userFavoritesRef = db.collection("users").document(userId);
        userFavoritesRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot documentSnapshot = task.getResult();
                if (documentSnapshot.exists()) {
                    // Retrieve the favorites list as an object
                    List<HashMap<String, Object>> favoriteData = (List<HashMap<String, Object>>) documentSnapshot.get("favorites");
                    favoriteList.clear();

                    // Convert each HashMap into a Favorite object
                    for (HashMap<String, Object> favoriteItem : favoriteData) {
                        String imdbID = (String) favoriteItem.get("imdbID");
                        String title = (String) favoriteItem.get("title");
                        String year = (String) favoriteItem.get("year");
                        String posterUrl = (String) favoriteItem.get("posterUrl");
                        String plot = (String) favoriteItem.get("plot");

                        // Create a new Favorite object
                        Favorite favorite = new Favorite(title, year, plot, posterUrl, imdbID);

                        // Add it to the list
                        favoriteList.add(favorite);
                    }

                    // Update the RecyclerView with the parsed data
                    setupAdapter();
                } else {
                    Toast.makeText(FavoriteActivity.this, "No favorites found", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(FavoriteActivity.this, "Failed to load favorites", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void setupAdapter() {
        adapter = new FavoriteMovieAdapter(favoriteList, position -> {
            Favorite selectedMovie = favoriteList.get(position);
            Intent intent = new Intent(FavoriteActivity.this, MovieEditActivity.class);
            intent.putExtra("title", selectedMovie.getTitle());
            intent.putExtra("year", selectedMovie.getYear());
            intent.putExtra("plot", selectedMovie.getPlot());
            intent.putExtra("posterUrl", selectedMovie.getPosterUrl());
            intent.putExtra("imdbID", selectedMovie.getImdbID());
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);
    }
}
