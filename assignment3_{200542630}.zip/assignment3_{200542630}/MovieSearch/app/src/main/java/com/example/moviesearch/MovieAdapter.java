package com.example.moviesearch;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MovieAdapter extends RecyclerView.Adapter<com.example.moviesearch.MovieAdapter.MovieViewHolder> {

    private Context context;
    private List<Movie> movieList;

    public MovieAdapter(Context context, List<Movie> movieList) {
        this.context = context;
        this.movieList = movieList;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item in the RecyclerView
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_movie, parent, false);
        return new MovieViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        Movie movieItem = movieList.get(position);

        // Set the title and year for the movie item
        holder.tvTitle.setText(movieItem.getTitle());
        holder.tvYear.setText(movieItem.getYear());

        // Load the poster image using Glide
        Glide.with(context)
                .load(movieItem.getPosterUrl())
                .into(holder.ivPoster);
        // Set OnClickListener for the item view
        holder.itemView.setOnClickListener(view -> {
            // Log for debugging
            Log.d("MovieAdapter", "Movie clicked: " + movieItem.getTitle());

            // Create intent to pass movie data to the details screen
            Intent intent = new Intent(context, MovieDetailsActivity.class);
            intent.putExtra("TITLE", movieItem.getTitle());
            intent.putExtra("YEAR", movieItem.getYear());
            intent.putExtra("POSTER", movieItem.getPosterUrl());
            intent.putExtra("imdbID", movieItem.getImdbID());

            // Start the MovieDetailsActivity
            context.startActivity(intent);
        });

        // Add to Favorites Button Click
//        holder.addToFavorites.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Prepare the movie data as a Map
//                Map<String, Object> movie = new HashMap<>();
//                movie.put("title", movieItem.getTitle());
//                movie.put("year", movieItem.getYear());
//                movie.put("posterUrl", movieItem.getPosterUrl());
//                movie.put("imdbID", movieItem.getImdbID());
//
//                // Get Firestore instance
//                FirebaseFirestore db = FirebaseFirestore.getInstance();
//
//                // Get the current user's UID
//                String userId = FirebaseAuth.getInstance().getCurrentUser() != null ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
//
//                if (userId != null) {
//                    // Reference to the user's document
//                    DocumentReference userFavoritesRef = db.collection("users").document(userId);
//
//                    // Check if the document exists
//                    userFavoritesRef.get().addOnCompleteListener(task -> {
//                        if (task.isSuccessful()) {
//                            if (!task.getResult().exists()) {
//                                // Create the document with an empty 'favorites' array if it doesn't exist
//                                Map<String, Object> initData = new HashMap<>();
//                                initData.put("favorites", new ArrayList<>()); // Initialize 'favorites' array
//                                userFavoritesRef.set(initData)
//                                        .addOnSuccessListener(aVoid -> Log.d("Firebase", "User document created"))
//                                        .addOnFailureListener(e -> Log.e("Firebase", "Error creating user document", e));
//                            }
//
//                            // Add the movie to the 'favorites' array
//                            userFavoritesRef.update("favorites", FieldValue.arrayUnion(movie))
//                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
//                                        @Override
//                                        public void onSuccess(Void unused) {
//                                            Log.d("Firebase", "Movie added to favorites.");
//                                            Toast.makeText(holder.itemView.getContext(), "Added to Favorites", Toast.LENGTH_SHORT).show();
//                                        }
//                                    })
//                                    .addOnFailureListener(new OnFailureListener() {
//                                        @Override
//                                        public void onFailure(@NonNull Exception e) {
//                                            Log.e("Firebase", "Error adding movie to favorites", e);
//                                            Toast.makeText(holder.itemView.getContext(), "Failed to add to Favorites", Toast.LENGTH_SHORT).show();
//                                        }
//                                    });
//                        } else {
//                            Log.e("Firebase", "Error fetching user document", task.getException());
//                        }
//                    });
//                } else {
//                    // If the user is not logged in
//                    Toast.makeText(context, "Please log in to add movies to favorites.", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//
    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }

    // ViewHolder class
    public static class MovieViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvYear;
        ImageView ivPoster;
        Button addToFavorites;

        public MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvYear = itemView.findViewById(R.id.tvYear);
            ivPoster = itemView.findViewById(R.id.moviePoster);
        }
    }
}
