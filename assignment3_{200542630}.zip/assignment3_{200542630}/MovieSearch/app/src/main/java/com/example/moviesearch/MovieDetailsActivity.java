package com.example.moviesearch;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;


public class MovieDetailsActivity extends AppCompatActivity {
    private TextView tvTitle, tvYear, tvPlot;
    private ImageView ivPoster;
    private Button btnBack;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        Button btnAddToFavorites = findViewById(R.id.btnAddToFavorites);

        // Initialize FirebaseAuth
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Please log in to use this feature.", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity if the user is not logged in
            return;
        }
        String userId = currentUser.getUid(); // Safely get the user ID

        // Initialize views
        tvTitle = findViewById(R.id.tvTitle);
        tvYear = findViewById(R.id.tvYear);
        tvPlot = findViewById(R.id.tvPlot);
        ivPoster = findViewById(R.id.ivPoster);
        btnBack = findViewById(R.id.btnBack);

        // Back button functionality
        btnBack.setOnClickListener(v -> finish());

        btnAddToFavorites.setOnClickListener(v -> {
            if (userId == null) {
                Toast.makeText(this, "Please log in to add movies to favorites.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Prepare the movie data as a Map
            Map<String, Object> movie = new HashMap<>();
            movie.put("title", tvTitle.getText().toString());
            movie.put("year", tvYear.getText().toString());
            movie.put("plot", tvPlot.getText().toString());
            movie.put("posterUrl", getIntent().getStringExtra("posterUrl"));
            movie.put("imdbID", getIntent().getStringExtra("imdbID"));

            // Reference to the user's document
            DocumentReference userFavoritesRef = db.collection("users").document(userId);

            // Check if the document exists and update
            userFavoritesRef.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    if (!task.getResult().exists()) {
                        // Create the document with an empty 'favorites' array if it doesn't exist
                        Map<String, Object> initData = new HashMap<>();
                        initData.put("favorites", new ArrayList<>()); // Initialize 'favorites' array
                        userFavoritesRef.set(initData)
                                .addOnSuccessListener(aVoid -> Log.d("Firebase", "User document created"))
                                .addOnFailureListener(e -> Log.e("Firebase", "Error creating user document", e));
                    }

                    // Add the movie to the 'favorites' array
                    userFavoritesRef.update("favorites", FieldValue.arrayUnion(movie))
                            .addOnSuccessListener(aVoid -> {
                                Log.d("Firebase", "Movie added to favorites.");
                                Toast.makeText(MovieDetailsActivity.this, "Added to Favorites", Toast.LENGTH_SHORT).show();
                            })
                            .addOnFailureListener(e -> {
                                Log.e("Firebase", "Error adding movie to favorites", e);
                                Toast.makeText(MovieDetailsActivity.this, "Failed to add to Favorites", Toast.LENGTH_SHORT).show();
                            });
                } else {
                    Log.e("Firebase", "Error fetching user document", task.getException());
                }
            });
        });

        // Get the imdbID from the Intent
        String imdbID = getIntent().getStringExtra("imdbID");
        if (imdbID != null) {
            fetchMovieDetails(imdbID); // Fetch detailed info
        }
    }

    private void fetchMovieDetails(String imdbID) {
        String url = "https://www.omdbapi.com/?apikey=7a19a300&i=" + imdbID; // Use "i=" for imdbID

        ApiClient.get(url, new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> Toast.makeText(MovieDetailsActivity.this, "Failed to fetch details", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String responseData = response.body().string();
                    runOnUiThread(() -> {
                        try {
                            parseMovieDetails(responseData);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    });
                }
            }
        });
    }

    private void parseMovieDetails(String data) throws JSONException {
        JSONObject jsonObject = new JSONObject(data);

        // Extract movie details
        String title = jsonObject.getString("Title");
        String year = jsonObject.getString("Year");
        String plot = jsonObject.getString("Plot");
        String posterUrl = jsonObject.getString("Poster");

        // Update UI
        tvTitle.setText(title);
        tvYear.setText(year);
        tvPlot.setText(plot);

        // Load the poster image
        Glide.with(this).load(posterUrl).into(ivPoster);
    }
}
