package com.example.moviesearch;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.moviesearch.databinding.ActivityMainBinding;
import com.google.firebase.FirebaseApp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private static final String API_KEY = "7a19a300";
    private static final String BASE_URL = "https://www.omdbapi.com/?apikey=" + API_KEY + "&s=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set up the RecyclerView
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Button click listener for searching movies
        binding.btnSearch.setOnClickListener(view -> searchMovies());

        // Button click listener for navigating to FavoriteActivity
        binding.btnFavorites.setOnClickListener(view -> {
            // Intent should point to the correct class: FavoriteActivity
            Intent intent = new Intent(MainActivity.this, FavoriteActivity.class); // Corrected
            startActivity(intent);
        });
    }

    // Search for movies based on the search query
    private void searchMovies() {
        String query = binding.etSearch.getText().toString();

        if (query.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter a search query", Toast.LENGTH_SHORT).show();
            return;
        }

        String getUrl = BASE_URL + query + "&type=movie";

        ApiClient.get(getUrl, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Failed to load data, please try again", Toast.LENGTH_SHORT).show();
                    Log.e("MovieSearch", "Error fetching data", e);
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();

                    try {
                        JSONObject jsonObject = new JSONObject(responseData);
                        JSONArray searchArray = jsonObject.optJSONArray("Search");

                        if (searchArray != null && searchArray.length() > 0) {
                            List<Movie> movieList = new ArrayList<>();
                            for (int i = 0; i < searchArray.length(); i++) {
                                JSONObject movieObject = searchArray.getJSONObject(i);
                                String title = movieObject.getString("Title");
                                String year = movieObject.getString("Year");
                                String posterUrl = movieObject.getString("Poster");
                                String imdbID = movieObject.getString("imdbID");
                                movieList.add(new Movie(title, year, posterUrl, imdbID));
                            }

                            // Update RecyclerView on the main thread
                            runOnUiThread(() -> {
                                MovieAdapter adapter = new MovieAdapter(MainActivity.this, movieList);
                                binding.recyclerView.setAdapter(adapter);
                            });
                        } else {
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, "No movies found", Toast.LENGTH_SHORT).show());
                        }
                    } catch (JSONException e) {
                        runOnUiThread(() -> Log.e("MovieSearch", "Error parsing JSON", e));
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show());
                }
            }
        });
    }
}
