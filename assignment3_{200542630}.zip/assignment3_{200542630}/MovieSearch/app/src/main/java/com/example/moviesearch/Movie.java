package com.example.moviesearch;

public class Movie {
    private String title;
    private String year;
    private String posterUrl;
    private String imdbID;

    public Movie(String title, String year, String posterUrl, String imdbID) {
        this.title = title;
        this.year = year;
        this.posterUrl = posterUrl;
        this.imdbID = imdbID;
    }

    public String getTitle() {
        return title;
    }

    public String getYear() {
        return year;
    }

    public String getPosterUrl() {
        return posterUrl;
    }

    public String getImdbID() {
        return imdbID;
    }
}
