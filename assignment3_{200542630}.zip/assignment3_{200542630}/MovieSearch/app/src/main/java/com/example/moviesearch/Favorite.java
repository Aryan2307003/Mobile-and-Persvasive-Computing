package com.example.moviesearch;

public class Favorite {
    private String title;
    private String year;
    private String plot;
    private String posterUrl;
    private String imdbID;

    // Constructor
    public Favorite(String title, String year, String plot, String posterUrl, String imdbID) {
        this.title = title;
        this.year = year;
        this.plot = plot;
        this.posterUrl = posterUrl;
        this.imdbID = imdbID;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getYear() {
        return year;
    }

    public String getPlot() {
        return plot;
    }

    public String getPosterUrl() {
        return posterUrl;
    }

    public String getImdbID() {
        return imdbID;
    }
}
