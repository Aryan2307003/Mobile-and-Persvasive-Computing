package com.example.moviesearch;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class ApiClient {

    private static final OkHttpClient client = new OkHttpClient();

    public static Call get(String url, okhttp3.Callback callback) {
        Request request = new Request.Builder()
                .url(url)
                .build();

        Call call = client.newCall(request);
        call.enqueue(callback); // Enqueue the request to handle asynchronously
        return call;
    }
}
